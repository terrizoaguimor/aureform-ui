# Aureform UI 1.4.0 — component sample

Eight original source components: Button, Input, Textarea, Card, Badge, Avatar, Alert and Skeleton. Their local imports, appearance props, semantic theme, pure palette configuration, token generator and its helper, local font assets and notices are included. The full suite is also open source at https://github.com/terrizoaguimor/aureform-ui; this smaller archive is an optional starting point with the same license.

Use Node 22.16+ and a Next.js / React / TypeScript / Tailwind CSS 4 project with @/* mapped to ./src/*. Merge the listed npm dependencies and copy the supplied src/components/ui, src/lib and src/styles files. Import the supplied globals.css, which imports tokens.css and effects.css, from your app's root layout. Keep their relative paths intact. Configure local fonts or use your existing interface font. pnpm tokens refreshes defaults from src/lib/appearance.ts and requires Node's type stripping. Individual local shadcn registry files are in public/r/.

Original Aureform files in this archive are licensed under the included Apache 2.0 LICENSE. Retain NOTICE and the applicable upstream notices when distributing them. Upstream libraries and fonts retain their licenses. The legacy aureform-ui-free.zip filename remains for existing links; it does not represent a separate license tier.
