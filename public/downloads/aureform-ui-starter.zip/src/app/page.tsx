"use client";
import {useState} from "react";
import {Providers,useTheme} from "@/components/providers";
import {PalettePicker} from "@/components/appearance-controls";
import {useAppearance} from "@/components/appearance-provider";
import {MotionSystem} from "@/components/motion-system";
import {GradientBackground} from "@/components/effects/gradient-background";
import {ShaderBackground} from "@/components/effects/shader-background";
import {SpotlightCard} from "@/components/effects/spotlight-card";
import {GlowBorder} from "@/components/effects/glow-border";
import {TiltCard} from "@/components/effects/tilt-card";
import {MagneticButton} from "@/components/effects/magnetic-button";
import {Brand} from "@/components/brand";
import {Button} from "@/components/ui/button";
import {Select} from "@/components/ui/select";
import {MetricCard} from "@/components/blocks/metric-card";
import {RevenuePanel} from "@/components/blocks/revenue-panel";
import {useLanguage} from "@/hooks/use-language";
function Workspace({onLanguage}:{onLanguage:()=>void}){
  const{l,locale}=useLanguage(),{theme,setTheme}=useTheme();
  const{appearance,setAppearance,resetAppearance}=useAppearance();
  const colors=Object.values(appearance.colors);
  return (
    <main className="mx-auto max-w-5xl px-6 py-12">
      <header className="mb-16 flex flex-wrap items-center justify-between gap-4">
        <Brand/>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={onLanguage}>{locale==="en"?"Español":"English"}</Button>
          <Button variant="outline" size="sm" onClick={()=>setTheme(theme==="light"?"dark":"light")}>{l("Switch theme","Cambiar tema")}</Button>
        </div>
      </header>
      <p className="text-xs text-muted-foreground">Aureform UI</p>
      <h1 data-motion="intro" className="editorial mt-4 text-5xl">{l("A good place to begin.","Un buen lugar para empezar.")}</h1>
      <p className="mt-5 text-sm text-muted-foreground">{l("Your source. Your next ambitious product.","Tu código. Tu próximo producto.")}</p>
      <section aria-label={l("Appearance","Apariencia")} className="my-8 grid gap-6 sm:grid-cols-2">
        <PalettePicker compact/>
        <Select label={l("Motion","Movimiento")} value={appearance.motion}
          onValueChange={(motion)=>setAppearance((current)=>({...current,motion:motion as typeof current.motion}))}
          options={[{value:"off",label:l("Off","Desactivado")},{value:"gentle",label:l("Gentle","Suave")},{value:"expressive",label:l("Expressive","Expresivo")}]}/>
      </section>
      <div data-motion="reveal" className="my-8 grid gap-4 sm:grid-cols-3">
        <MetricCard label={l("Monthly revenue","Ingresos mensuales")} value="$48,295" change="+12.8%" trend="up"/>
        <MetricCard label={l("Customers","Clientes")} value="2,420"/>
        <MetricCard label={l("Growth","Crecimiento")} value="8.2%"/>
      </div>
      <RevenuePanel title={l("A little perspective","Un poco de perspectiva")} description={l("Illustrative local data.","Datos locales ilustrativos.")} label={l("Demo revenue","Ingresos de ejemplo")} valueLabel={l("Revenue","Ingresos")} data={[{label:"May",value:24000},{label:"Jun",value:31000},{label:"Jul",value:28500},{label:"Aug",value:36000},{label:"Sep",value:41200},{label:"Oct",value:48295}]}/>
      <section aria-label={l("Visual effects","Efectos visuales")} className="mt-8 grid gap-4 sm:grid-cols-2">
        <GradientBackground kind={appearance.gradient.kind} colors={appearance.gradient.stops.map((stop)=>stop.color)} angle={appearance.gradient.angle} intensity={appearance.gradient.intensity} className="p-6">
          <h2 className="text-xl font-semibold">{l("A color field, in your palette.","Un campo de color con tu paleta.")}</h2>
        </GradientBackground>
        <ShaderBackground {...appearance.shader} colors={colors} paused={appearance.shader.paused || appearance.motion==="off"} className="p-6">
          <h2 className="text-xl font-semibold">{l("An original shader atmosphere.","Una atmósfera con shaders originales.")}</h2>
        </ShaderBackground>
        <SpotlightCard><p>{l("A subtle light follows your pointer.","Una luz sutil sigue tu puntero.")}</p></SpotlightCard>
        <GlowBorder colors={colors}><p>{l("A border with a little energy.","Un borde con un poco de energía.")}</p></GlowBorder>
        <TiltCard><p>{l("Quiet depth for a featured surface.","Profundidad suave para una superficie destacada.")}</p></TiltCard>
        <div className="flex items-center justify-center rounded-xl border border-border p-6">
          <MagneticButton onClick={resetAppearance}>{l("Reset appearance","Restablecer apariencia")}</MagneticButton>
        </div>
      </section>
      <p className="mt-8 text-xs text-muted-foreground">{l("Edit src/app/page.tsx and add components with the local Aureform CLI.","Edita src/app/page.tsx y añade componentes con la CLI local de Aureform.")}</p>
    </main>
  );
}
export default function Home(){const[locale,setLocale]=useState<"en"|"es">("en");return <Providers locale={locale}><MotionSystem><Workspace onLanguage={()=>setLocale(locale==="en"?"es":"en")}/></MotionSystem></Providers>;}
