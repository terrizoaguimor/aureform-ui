import type {Metadata} from "next";
import {DocumentLayout} from "@/components/document-layout";
export {viewport} from "@/components/document-layout";
export const metadata: Metadata = {
  title: "Aureform — your next product",
  description: "A refined starting point for your Next.js product.",
  icons: {icon: "/favicon.svg"}
};
export default function RootLayout({children}: Readonly<{children: React.ReactNode}>) {
  return <DocumentLayout locale="en">{children}</DocumentLayout>;
}
