# Aureform 1.3.0 starter

Node 22.16+ and pnpm 10.

```sh
pnpm install
pnpm dev
pnpm build
pnpm start
```

The overview includes Aurora, Violet, Ocean, Mint, Ember and Rose palettes, Light/Dark controls, AppearanceProvider, MotionSystem, GradientBackground, ShaderBackground, SpotlightCard, GlowBorder, TiltCard and MagneticButton. The provider stores appearance in this browser; the page's records are illustrative local data.

Edit src/app/page.tsx. Use useAppearance() beneath Providers to change settings, or AppearanceScope for an isolated configured example. The source appearance library includes createAppearance(), serializeAppearance() and appearanceToCSS(). The token generator and its appearance-tokens helper are included; pnpm tokens refreshes CSS from the same pure configuration. pnpm build exports to out/ and pnpm start serves it.

The full suite's /en/studio/, /en/themes/ and /en/effects/ screens live in the complete open-source kit at https://github.com/terrizoaguimor/aureform-ui. This starter's home exposes its own palette and motion controls. Add further source using the CLI from your extracted kit, then install merged dependencies in this project.

Original Aureform code and assets are licensed under Apache 2.0, including this starter and the full suite. Keep LICENSE and NOTICE when distributing the work; see LICENSE.md for scope and THIRD_PARTY_NOTICES.md for independent upstream licenses. Authentication, billing and model providers require your own integration.
