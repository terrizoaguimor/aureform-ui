# Aureform UI 1.3.0 — generated image collection

32 fictional generated assets: 16 portrait avatars, two organization avatars, eight product photos and six editorial images. Original masters in design/images/masters, optimized WebP files and self-contained SVG wrappers are included, with the immutable 1.2.1 image manifest, dimensions, EN/ES alternative text, SHA-256 values and full generation prompt catalog.

Extract this archive into your Next.js project root to preserve public/assets/... paths. Use /assets/<group>/<id>.svg with the supplied components or /assets/<group>/<id>.webp with your image component. The SVG contains the exact optimized WebP as a data URI: it is portable raster content, not editable vector artwork. Aureform's text registry can deliver this SVG through the official shadcn 4.22.0 installer. The local CLI and ZIP deliveries preserve binary WebP bytes.

No API key, image generation SDK, backend or remote image host is needed to display these files. All 32 original masters are openly distributed in this archive and the source package. Prompts document provenance; they do not imply that the receiving project must generate images. The historical image manifest records the original generation-workspace paths; use the same master filenames under design/images/masters in this distribution.

The original Aureform collection, prompts and masters are licensed under the included Apache 2.0 LICENSE, to the extent the contributors hold rights in them. Keep NOTICE when redistributing. The starter, eight-component sample and full source use the same license. Native asset review and delivery QA retain their own recorded scopes: the 1.2.1 image checkpoint is historical evidence, not a new native review of this source release.
